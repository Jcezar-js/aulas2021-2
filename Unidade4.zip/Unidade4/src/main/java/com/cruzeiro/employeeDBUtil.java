package com.cruzeiro;
import javax.sql.DataSource;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class employeeDBUtil {
	private DataSource dataSource;
	
	public employeeDBUtil(DataSource datasource) {
		this.dataSource = datasource;
	}
	
	public List<employee> getEmployee() throws Exception{
		
		List <employee> employees = new ArrayList<>();
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = dataSource.getConnection();
			String sql = "SELECT idEmployee, nameEmployee, functionEmployee, emailEmployee, salaryEmployee FROM projetoCrud ORDER BY idEmployee";
			
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				int id = rs.getInt("idEmployee");
				String name = rs.getString("nameEmployee");
				String function = rs.getString("functionEmployee");
				String email = rs.getString("emailEmployee");
				int salary = rs.getInt("salaryEmployee");
				
				employee tempEmployee = new employee(id,name,function, email, salary);
						
				employee.add(tempEmployee);
			}
			
		}finally{
			
		}
		
	}
}
