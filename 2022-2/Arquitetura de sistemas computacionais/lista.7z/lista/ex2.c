#include <stdio.h>
#include <stdlib.h>

int ex2 (void){
	
	char nome [61];
	
	printf("Digite seu Nome:");
	gets(nome);
	
	
	
	return EXIT_SUCCESS;
}
